## Test environments
* local OS X install, R 3.5.3
* https://builder.r-hub.io Fedora Linux, R-devel, clang, gfortran
* win-builder (devel and release)


## R CMD check results
0 ERRORs, 0 WARNING, 0 NOTES

## rhub build results
0 ERRORs, 0 WARNING, 1 NOTE

Possibly mis-spelled words in DESCRIPTION:
  auROC (14:72)
  genomics (14:141)
  Scalable (14:14)
  SingleCellExperiment (14:181)
  