library(testthat)
library(presto)

test_check("presto")
